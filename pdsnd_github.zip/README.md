>**Note**: Please **fork** the current Udacity repository so that you will have a **remote** repository in **your** Github account. Clone the remote repository to your local machine. Later, as a part of the project "Post your Work on Github", you will push your proposed changes to the remote repository in your Github account.

### Date created
2023-05-12

### Project Title
* Bikeshare-Analysis on __Git__

### Description
<sub> It is only an attempt to place a simple python project on Github </sub>

### Files used
* bikeshare.py
* .gitignore

### Credits
Credits go to https://github.com/udacity/pdsnd_github

<<<<<<< HEAD

### Changes in Documtation branch
* __It is a neu comment due to git  Documentation__
=======
### Refractoring Code, Add new comment #Create def for Filters
>>>>>>> refractoring
